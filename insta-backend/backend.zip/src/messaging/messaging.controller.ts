import { Controller } from '@nestjs/common';

@Controller('messaging')
export class MessagingController {}
