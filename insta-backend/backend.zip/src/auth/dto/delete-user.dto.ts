export class DeleteUserDto {
  username: string;
  password: string;
}
